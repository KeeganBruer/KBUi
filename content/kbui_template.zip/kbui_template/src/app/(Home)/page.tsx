import PageConstraint from "@/Components/PageConstraint";
import PageWrapper from "@/Components/PageWrapper";
import Image from "next/image";

export default function Home() {
  return (
    <PageWrapper>
      <PageConstraint>
        Welcome
      </PageConstraint>
    </PageWrapper>
  );
}
