import { ReactNode } from "react";

export default (props:{children?:ReactNode}) => {
    return (
        <div className="flex flex-col w-full items-center">
            {props.children}
        </div>
    )
}